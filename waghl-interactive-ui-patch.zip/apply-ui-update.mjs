/**
 * Patch only the interactive UI and the matching argument names in an already
 * installed WAGHL node. Does not overwrite credentials, CI or other operations.
 * Designed to run from the root of your current Codespaces repository.
 */
import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const filename = path.join(root, 'nodes/Waghl/Waghl.node.ts');
const helperFile = path.join(root, 'nodes/Waghl/interactive.ts');
const uiFields = fs.readFileSync(new URL('./ui-fields.txt', import.meta.url), 'utf8');
if (!fs.existsSync(filename) || !fs.existsSync(helperFile)) {
  throw new Error('Run from your existing WAGHL repository after installing the interactive add-on');
}
const original = fs.readFileSync(filename, 'utf8');
const first = original.indexOf('      // --- Interactive messages:');
const endMarker = '    ],\n  };\n\n  async execute';
const last = original.indexOf(endMarker, first);
if (first < 0 || last < 0 || !original.includes('interactiveListJson') || !original.includes('interactiveCardsJson')) {
  throw new Error('Expected original interactive form fields were not found; no files changed');
}
let updated = original.slice(0, first) + uiFields + original.slice(last);
updated = updated.replace("this.getNodeParameter('interactiveListJson', itemIndex, '[]')",
  "this.getNodeParameter('interactiveSections', itemIndex, {})");
updated = updated.replace("this.getNodeParameter('interactiveCardsJson', itemIndex, '[]')",
  "this.getNodeParameter('interactiveCards', itemIndex, {})");
if (updated.includes("this.getNodeParameter('interactiveListJson'") ||
    updated.includes("this.getNodeParameter('interactiveCardsJson'")) {
  throw new Error('Some original JSON field references remain; no files changed');
}
const helper = fs.readFileSync(helperFile, 'utf8');
const begin = helper.indexOf('function normalizeButtons(');
const finish = helper.indexOf('export function buildInteractivePayload(', begin);
if (begin < 0 || finish < 0) throw new Error('Expected payload builder was not found; no files changed');
const replacement = fs.readFileSync(new URL('./ui-normalizers.txt', import.meta.url), 'utf8');
const updatedHelper = helper.slice(0, begin) + replacement + helper.slice(finish);
const testPath = path.join(root, 'test/interactive.test.cjs');
if (!fs.existsSync(testPath)) throw new Error('Interactive tests not found; no files changed');
const originalTests = fs.readFileSync(testPath, 'utf8');
const oldTestStart = originalTests.indexOf("test('invalid recipient and missing carousel image rejected'");
const oldTestEnd = originalTests.indexOf("test('interactive responses:", oldTestStart);
if (oldTestStart < 0 || oldTestEnd < 0) {
  throw new Error('Existing tests differ from the expected add-on; no files changed');
}
const newTests = fs.readFileSync(new URL('./ui-tests.txt', import.meta.url), 'utf8');
const updatedTests = originalTests.slice(0, oldTestStart) + newTests + originalTests.slice(oldTestEnd);
const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
fs.copyFileSync(filename, `${filename}.${timestamp}.bak`);
fs.copyFileSync(helperFile, `${helperFile}.${timestamp}.bak`);
fs.copyFileSync(testPath, `${testPath}.${timestamp}.bak`);
fs.writeFileSync(filename, updated);
fs.writeFileSync(helperFile, updatedHelper);
fs.writeFileSync(testPath, updatedTests);
console.log('Interactive forms and request normalization updated. Original files backed up as .bak.');
console.log('Run: npm run lint:fix && npm test && npm pack --dry-run');
